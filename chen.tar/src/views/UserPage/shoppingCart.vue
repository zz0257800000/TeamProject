<script>
import api from "../../api/api";
export default {
  data() {
    return {
<<<<<<< HEAD
      itemList: [
        {
          productId: '1',
          itemName: '優質短袖白T',
          imgUrl: 'https://images.unsplash.com/photo-1534961880437-ce5ae2033053?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=668&q=80',
          price: '500',
          count: '2'
        },
        {
          productId: '2',
          itemName: '骷髏手短黑T',
          imgUrl: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1500&q=80',
          price: '790',
          count: '3'
        },
        {
          productId: '3',
          itemName: '超時尚牛仔褲',
          imgUrl: 'https://images.unsplash.com/photo-1529391409740-59f2cea08bc6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1124&q=80',
          price: '1200',
          count: '1'
        },
        {
          productId: '4',
          itemName: '質感褐色系大衣服',
          imgUrl: 'https://images.unsplash.com/photo-1491998664548-0063bef7856c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1500&q=80',
          price: '2300',
          count: '1'
        },
      ]
=======
     
>>>>>>> kamishu
    };
  },
  methods: {
    handlePlus: function (item) {
      item.count++;
    },
    handleSub: function (item) {
      if (item.count > 1) {
        item.count--;
      }
    },
    handledelete: function (index) {
    // 获取要删除的项目
    const deletedItem = this.itemList[index];

    // 从前端中删除项目
    this.itemList.splice(index, 1);

    // 打印被删除项目的id
    console.log('Deleted item id:', deletedItem.productId);

    // 调用API删除购物车中的项目
    api.cartDelete(deletedItem.productId)
      .then(response => {
        // 处理API响应，如果需要的话
        console.log('cartDelete:', response);
      })
      .catch(error => {
        // 处理错误，如果需要的话
        console.error('Error deleting item from cart:', error);
      });
  },
  },
  computed: {

  }
}

</script>

<template>
  <div class="cart-page">
    <div class="page-header">
      <RouterLink class="home-link" to="/">Home</RouterLink>
      <span class="breadcrumb-separator">></span>
      <span class="current-page">購物車</span>
    </div>

    <div class="cart-items">
      <div v-for="(item, index) in itemList" :key="item.id" class="cart-item">
        <div class="item-image">
          <img :src="item.imgUrl" alt="">
        </div>
        <div class="item-details">
          <div class="item-name">{{ item.itemName }}</div>
          <div class="item-price">
            <span class="price-label">單價：</span>
            <span class="price-value">{{ item.price }}</span>
          </div>
          <div class="item-quantity">
            <button @click="handleSub(item)">-</button>
            <span class="quantity-value">{{ item.count }}</span>
            <button @click="handlePlus(item)">+</button>
          </div>
          <div class="item-total">
            <span class="total-label">總計：</span>
            <span class="total-value">{{ item.price * item.count }}</span>
          </div>
          <button @click="handledelete(index)" class="delete-button">刪除</button>
        </div>
      </div>
    </div>

    <RouterLink class="checkout-button" to="/">結帳</RouterLink>
  </div>
</template>
<style lang="scss" scoped>
.cart-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  font-family: 'Roboto', sans-serif;
  color: #333;
}

.page-header {
  margin-bottom: 20px;
}

.home-link {
  border-radius: 5px;
  padding: 5px;
  transition: background 0.3s ease;
  text-decoration: none;
  color: black;

  &:hover {
    background-color: #ddd;
  }
}

.breadcrumb-separator {
  margin: 0 5px;
}

.current-page {
  font-weight: bold;
}

.cart-items {
  width: 100%;
}

.cart-item {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  padding: 10px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

  .item-image {
    margin-right: 20px;

    img {
      width: 80px;
      height: 80px;
      border-radius: 5px;
    }
  }

  .item-details {
    flex-grow: 1;

    .item-name {
      font-size: 18px;
      margin-bottom: 10px;
    }

    .item-price,
    .item-quantity,
    .item-total {
      margin-bottom: 8px;
    }

    .quantity-value {
      margin: 0 5px;
    }

    .delete-button {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 8px;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;

      &:hover {
        background-color: #c0392b;
      }
    }
  }
}

.checkout-button {
  margin-top: 20px;
  background-color: #2ecc71;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  text-decoration: none;
  cursor: pointer;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #27ae60;
  }
}
</style>